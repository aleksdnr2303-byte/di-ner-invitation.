import express from "express";
import Database from "better-sqlite3";
import dotenv from "dotenv";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const db = new Database("data.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS invites (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 slug TEXT UNIQUE NOT NULL,
 title TEXT NOT NULL,
 message TEXT NOT NULL,
 yes_text TEXT NOT NULL,
 no_text TEXT NOT NULL,
 date_label TEXT NOT NULL,
 time_label TEXT NOT NULL,
 theme TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS replies (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 invite_slug TEXT NOT NULL,
 answer TEXT NOT NULL,
 chosen_date TEXT,
 chosen_time TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const BOT_TOKEN = process.env.BOT_TOKEN || "";
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "di_ner";
const sessions = new Set();
let telegramOffset = 0;

function auth(req,res,next) {
 const h = req.headers.authorization || "";
 const token = h.startsWith("Bearer ") ? h.slice(7) : "";
 if (!token || !sessions.has(token)) return res.status(401).json({error:"Нужен вход"});
 next();
}
function safeInvite(row) {
 if (!row) return null;
 return {slug:row.slug,title:row.title,message:row.message,yesText:row.yes_text,
 noText:row.no_text,dateLabel:row.date_label,timeLabel:row.time_label,theme:row.theme};
}
async function sendTelegram(text) {
 const chat = db.prepare("SELECT value FROM settings WHERE key='admin_chat_id'").get()?.value;
 if (!BOT_TOKEN || !chat) return false;
 const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
  method:"POST", headers:{"content-type":"application/json"},
  body:JSON.stringify({chat_id:chat,text,parse_mode:"HTML"})
 });
 return r.ok;
}
async function pollTelegram() {
 if (!BOT_TOKEN) return;
 try {
  const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getUpdates?offset=${telegramOffset}&timeout=20`);
  const data = await r.json();
  if (data.ok) for (const u of data.result) {
   telegramOffset = u.update_id + 1;
   if (u.message?.text?.startsWith("/start")) {
    const chatId = String(u.message.chat.id);
    db.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('admin_chat_id',?)").run(chatId);
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,{
     method:"POST",headers:{"content-type":"application/json"},
     body:JSON.stringify({chat_id:chatId,text:"Готово! Уведомления о приглашениях будут приходить сюда. Аккаунт для финального экрана: @"+ADMIN_USERNAME})
    });
   }
  }
 } catch {}
}
if (BOT_TOKEN) setInterval(pollTelegram, 2500);

app.post("/api/login",(req,res)=>{
 if (!ADMIN_PASSWORD || req.body.password !== ADMIN_PASSWORD) return res.status(403).json({error:"Неверный пароль"});
 const token = crypto.randomBytes(32).toString("hex");
 sessions.add(token);
 res.json({token});
});
app.get("/api/invites",auth,(req,res)=>{
 res.json(db.prepare("SELECT * FROM invites ORDER BY id DESC").all().map(safeInvite));
});
app.post("/api/invites",auth,(req,res)=>{
 const b=req.body||{};
 const slug=crypto.randomBytes(5).toString("hex");
 const data=[slug,b.title||"Приглашение на свидание",b.message||"Хочу провести этот день вместе с тобой ❤️",
 b.yesText||"Да, с удовольствием",b.noText||"Не получится",b.dateLabel||"Выбери дату",
 b.timeLabel||"Выбери время",b.theme||"rose"];
 db.prepare("INSERT INTO invites(slug,title,message,yes_text,no_text,date_label,time_label,theme) VALUES(?,?,?,?,?,?,?,?)").run(...data);
 res.json({slug});
});
app.put("/api/invites/:slug",auth,(req,res)=>{
 const b=req.body||{};
 const result=db.prepare(`UPDATE invites SET title=?,message=?,yes_text=?,no_text=?,date_label=?,time_label=?,theme=? WHERE slug=?`)
 .run(b.title,b.message,b.yesText,b.noText,b.dateLabel,b.timeLabel,b.theme,req.params.slug);
 res.json({ok:result.changes>0});
});
app.get("/api/public/:slug",(req,res)=>{
 const row=db.prepare("SELECT * FROM invites WHERE slug=?").get(req.params.slug);
 if(!row) return res.status(404).json({error:"Приглашение не найдено"});
 res.json({...safeInvite(row),username:ADMIN_USERNAME});
});
app.post("/api/public/:slug/reply",async(req,res)=>{
 const row=db.prepare("SELECT * FROM invites WHERE slug=?").get(req.params.slug);
 if(!row) return res.status(404).json({error:"Приглашение не найдено"});
 const answer=String(req.body.answer||"").slice(0,80);
 const date=String(req.body.date||"").slice(0,40);
 const time=String(req.body.time||"").slice(0,40);
 if(!answer) return res.status(400).json({error:"Выбери ответ"});
 db.prepare("INSERT INTO replies(invite_slug,answer,chosen_date,chosen_time) VALUES(?,?,?,?)").run(row.slug,answer,date,time);
 const msg=`💌 <b>Ответ на приглашение</b>\n\n<b>${escapeHtml(row.title)}</b>\nОтвет: ${escapeHtml(answer)}\nДата: ${escapeHtml(date||"не выбрана")}\nВремя: ${escapeHtml(time||"не выбрано")}\n\nСсылка: ${process.env.PUBLIC_URL||""}/p/${row.slug}`;
 const sent=await sendTelegram(msg);
 res.json({ok:true,telegramSent:sent,username:ADMIN_USERNAME});
});
function escapeHtml(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));}
app.get("/p/:slug",(req,res)=>res.sendFile(path.join(__dirname,"public","invite.html")));
app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Invitation app listening on ${port}`));
